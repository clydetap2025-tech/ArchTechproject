// Vercel serverless: озвучка записи. Голос и манеру выбирает визуальная система (js/rules.js), а не модель.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(501).json({ error: 'no key' });
  const { text, voice, instructions, speed } = req.body || {};
  const r = await fetch('https://api.openai.com/v1/audio/speech', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: 'gpt-4o-mini-tts',
      input: String(text || '').slice(0, 3500),
      voice: voice || 'sage',
      instructions,
      speed,
      response_format: 'mp3',
    }),
  });
  if (!r.ok) return res.status(r.status).send(await r.text());
  res.setHeader('Content-Type', 'audio/mpeg');
  res.status(200).send(Buffer.from(await r.arrayBuffer()));
}
