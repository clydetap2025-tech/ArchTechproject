// Vercel serverless: прокси к OpenAI, ключ в переменной окружения OPENAI_API_KEY.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(501).json({ error: 'no key' });
  const { messages, model } = req.body || {};
  const r = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: model || 'gpt-4o-mini',
      messages,
      response_format: { type: 'json_object' },
      temperature: 0.7,
    }),
  });
  if (!r.ok) return res.status(r.status).json({ error: await r.text() });
  const j = await r.json();
  try {
    res.status(200).json(JSON.parse(j.choices[0].message.content));
  } catch {
    res.status(502).json({ error: 'bad json' });
  }
}
