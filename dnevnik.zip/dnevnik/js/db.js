// IndexedDB: каждый день — отдельная «папка» со всем содержимым (текст, фото, песня, озвучка, анализ).
const DB_NAME = 'atmos-diary';
const STORE = 'days';
let dbp;

function open() {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const s = req.result.createObjectStore(STORE, { keyPath: 'id' });
      s.createIndex('date', 'date');
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbp;
}

function tx(mode, fn) {
  return open().then(db => new Promise((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    const s = t.objectStore(STORE);
    const r = fn(s);
    t.oncomplete = () => resolve(r && r.result !== undefined ? r.result : r);
    t.onerror = () => reject(t.error);
  }));
}

export const saveDay = day => tx('readwrite', s => s.put(day));
export const getDay = id => tx('readonly', s => s.get(id));
export const deleteDay = id => tx('readwrite', s => s.delete(id));
export async function listDays() {
  const all = await tx('readonly', s => s.getAll());
  return (all || []).sort((a, b) => (b.date + b.created).localeCompare(a.date + a.created));
}
