// Аудиоанализ своего файла прямо в браузере: темп (BPM), энергия, яркость звука, мажор/минор.
// Файл не уходит на сервер.

export async function analyzeAudio(blob) {
  const buf = await blob.arrayBuffer();
  const Ctx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  const ac = new Ctx(1, 44100, 44100);
  const audio = await ac.decodeAudioData(buf);
  const sr = audio.sampleRate;
  // берём до 45 секунд из середины трека
  const ch0 = audio.getChannelData(0);
  const ch1 = audio.numberOfChannels > 1 ? audio.getChannelData(1) : ch0;
  const len = Math.min(ch0.length, sr * 45);
  const start = Math.max(0, Math.floor((ch0.length - len) / 2));
  const x = new Float32Array(len);
  for (let i = 0; i < len; i++) x[i] = (ch0[start + i] + ch1[start + i]) / 2;

  // энергия и «яркость» (частота пересечений нуля)
  let sq = 0, zc = 0;
  for (let i = 1; i < len; i++) { sq += x[i] * x[i]; if ((x[i] >= 0) !== (x[i - 1] >= 0)) zc++; }
  const rms = Math.sqrt(sq / len);
  const brightness = Math.min(1, (zc / len) * sr / 4000);

  // огибающая начал нот → автокорреляция → темп
  const hop = 512, win = 1024;
  const env = [];
  let prev = 0;
  for (let i = 0; i + win < len; i += hop) {
    let e = 0;
    for (let j = 0; j < win; j++) e += x[i + j] * x[i + j];
    e = Math.sqrt(e / win);
    env.push(Math.max(0, e - prev));
    prev = e;
  }
  const fps = sr / hop;
  let bestLag = 0, best = -Infinity;
  const minLag = Math.floor(fps * 60 / 180), maxLag = Math.ceil(fps * 60 / 60);
  for (let lag = minLag; lag <= maxLag; lag++) {
    let s = 0;
    for (let i = 0; i + lag < env.length; i++) s += env[i] * env[i + lag];
    // лёгкое предпочтение темпов около 100 BPM, чтобы не прыгать на половинный/двойной
    const bpm = 60 * fps / lag;
    s *= Math.exp(-Math.pow(Math.log2(bpm / 100), 2) / 1.2);
    if (s > best) { best = s; bestLag = lag; }
  }
  const bpm = Math.round(60 * fps / Math.max(1, bestLag));

  // хрома через Гёрцеля на 12 нотах × 3 октавы → корреляция с профилями Крумхансла
  const chroma = new Array(12).fill(0);
  const N = 4096, frames = Math.min(60, Math.floor(len / N));
  const step = Math.floor(len / Math.max(1, frames));
  for (let f = 0; f < frames; f++) {
    const off = f * step;
    for (let oct = 3; oct <= 5; oct++) {
      for (let p = 0; p < 12; p++) {
        const freq = 440 * Math.pow(2, (p - 9) / 12 + (oct - 4));
        const w = 2 * Math.cos((2 * Math.PI * freq) / sr);
        let s1 = 0, s2 = 0;
        for (let i = 0; i < N; i++) { const s0 = x[off + i] + w * s1 - s2; s2 = s1; s1 = s0; }
        chroma[p] += Math.sqrt(Math.max(0, s1 * s1 + s2 * s2 - w * s1 * s2));
      }
    }
  }
  const MAJ = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
  const MIN = [6.33, 2.68, 3.52, 5.38, 2.6, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];
  const corr = (a, b) => {
    const ma = a.reduce((s, v) => s + v, 0) / 12, mb = b.reduce((s, v) => s + v, 0) / 12;
    let num = 0, da = 0, db = 0;
    for (let i = 0; i < 12; i++) { num += (a[i] - ma) * (b[i] - mb); da += (a[i] - ma) ** 2; db += (b[i] - mb) ** 2; }
    return num / Math.sqrt(da * db || 1);
  };
  let bestKey = { r: -2, mode: 'major', tonic: 0 };
  for (let t = 0; t < 12; t++) {
    const rot = chroma.slice(t).concat(chroma.slice(0, t));
    const rM = corr(rot, MAJ), rm = corr(rot, MIN);
    if (rM > bestKey.r) bestKey = { r: rM, mode: 'major', tonic: t };
    if (rm > bestKey.r) bestKey = { r: rm, mode: 'minor', tonic: t };
  }
  const NOTES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const loud = Math.min(1, rms / 0.25);
  const energy = Math.min(1, 0.55 * loud + 0.3 * Math.min(1, Math.max(0, (bpm - 60) / 110)) + 0.15 * brightness);

  return {
    bpm, energy, brightness, loudness: loud,
    mode: bestKey.mode, key: `${NOTES[bestKey.tonic]} ${bestKey.mode === 'minor' ? 'minor' : 'major'}`,
    duration: audio.duration, source: 'audio',
  };
}

// Метаданные по ссылке (YouTube / Spotify) через oEmbed — название трека для модели
export async function linkMeta(url) {
  try {
    if (/spotify\.com/.test(url)) {
      const r = await fetch(`https://open.spotify.com/oembed?url=${encodeURIComponent(url)}`);
      if (r.ok) { const j = await r.json(); return j.title; }
    }
    if (/youtu\.?be/.test(url)) {
      const r = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(url)}`);
      if (r.ok) { const j = await r.json(); return [j.title, j.author_name].filter(Boolean).join(' — '); }
    }
  } catch {}
  return '';
}

export function embedFor(url) {
  if (!url) return '';
  let m = url.match(/(?:youtu\.be\/|v=|shorts\/)([\w-]{11})/);
  if (m) return `https://www.youtube.com/embed/${m[1]}?autoplay=0`;
  m = url.match(/open\.spotify\.com\/(track|album|playlist)\/(\w+)/);
  if (m) return `https://open.spotify.com/embed/${m[1]}/${m[2]}`;
  m = url.match(/music\.yandex\.\w+\/album\/(\d+)\/track\/(\d+)/);
  if (m) return `https://music.yandex.ru/iframe/track/${m[2]}/${m[1]}`;
  return '';
}
