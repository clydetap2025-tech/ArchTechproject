// Разбор записи дня. Порядок: серверная функция /api/analyze → прямой вызов OpenAI с локальным ключом → офлайн-эвристика.
// Модель только описывает день (оси настроения, название, подпись). Как день будет выглядеть, решают правила в rules.js.

export const SYSTEM_PROMPT = `Ты — редактор личного дневника атмосфер. Тебе дают запись о дне (по-русски), иногда фото и описание песни.
Верни ТОЛЬКО JSON такого вида:
{
 "title": "название папки дня, 3–7 слов, без точки и кавычек, как подпись к фотоальбому: место или время + одна живая деталь из записи. Примеры: «Осенний парк и какао», «Ночь в офисе перед сдачей», «Первый снег у бабушки на кухне»",
 "caption": "одна короткая рукописная строка от первого лица, до 60 символов, тёплая и конкретная, без пафоса",
 "mood": {
   "valence": число от -1 (тяжело) до 1 (радостно),
   "energy": 0..1 (насколько день был быстрым и насыщенным),
   "warmth": 0..1 (ощущение тепла: люди, уют, свет — не только температура),
   "tension": 0..1 (давление, спешка, тревога, дедлайн),
   "nostalgia": 0..1 (светлая грусть, воспоминание, «как раньше»),
   "social": 0..1 (сколько людей и общения),
   "calm": 0..1 (тишина, медленность)
 },
 "time_of_day": "morning|day|evening|night",
 "season": "winter|spring|summer|autumn|unknown",
 "setting": "nature|city|home|office|water|road|other",
 "keywords": ["3–5 конкретных образов из записи, по одному-два слова"],
 "senses": "одна фраза: что было слышно, чем пахло, какой был свет (только из записи или фото, не выдумывай)",
 "song": {"genre": "жанр", "era": "десятилетие", "tempo_bpm": число, "mode": "major|minor", "energy": 0..1, "known": true/false},
 "photo_notes": "что на фото и какой там свет, одной фразой (если фото есть)"
}
Не ставь диагнозов и не оценивай психику — описывай атмосферу.`;

async function toThumbDataURL(blob, max = 512) {
  const bmp = await createImageBitmap(blob);
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.7);
}

function buildMessages(input, thumbs) {
  const songLine = input.songMeta
    ? `Песня: ${input.songMeta}${input.audioFeatures ? `. Аудиоанализ: темп ≈ ${input.audioFeatures.bpm} BPM, лад ${input.audioFeatures.mode === 'minor' ? 'минор' : 'мажор'}, энергия ${input.audioFeatures.energy.toFixed(2)}` : ''}`
    : 'Песня не указана.';
  const content = [{ type: 'text', text: `Дата: ${input.date}\nЗапись:\n${input.text}\n\n${songLine}` }];
  thumbs.forEach(url => content.push({ type: 'image_url', image_url: { url, detail: 'low' } }));
  return [{ role: 'system', content: SYSTEM_PROMPT }, { role: 'user', content }];
}

export function getSettings() {
  try { return JSON.parse(localStorage.getItem('atmos-settings') || '{}'); } catch { return {}; }
}
export function setSettings(s) {
  try { localStorage.setItem('atmos-settings', JSON.stringify(s)); } catch {}
}

export async function analyzeDay(input) {
  const thumbs = [];
  for (const p of input.photos.slice(0, 3)) {
    try { thumbs.push(await toThumbDataURL(p)); } catch {}
  }
  const messages = buildMessages(input, thumbs);
  const settings = getSettings();
  const model = settings.model || 'gpt-4o-mini';

  // 1. серверная функция (ключ хранится в переменных окружения Vercel)
  try {
    const r = await fetch('api/analyze', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, model }),
    });
    if (r.ok) { const j = await r.json(); if (j.mood) return normalize(j, 'openai'); }
  } catch {}

  // 2. локальный ключ (только для разработки)
  if (settings.key) {
    try {
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${settings.key}` },
        body: JSON.stringify({ model, messages, response_format: { type: 'json_object' }, temperature: 0.7 }),
      });
      if (r.ok) {
        const j = await r.json();
        return normalize(JSON.parse(j.choices[0].message.content), 'openai');
      }
      console.warn('OpenAI error', r.status, await r.text());
    } catch (e) { console.warn(e); }
  }

  // 3. офлайн
  return normalize(heuristic(input), 'offline');
}

const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, Number.isFinite(+v) ? +v : (a + b) / 2));

function normalize(j, source) {
  const m = j.mood || {};
  const words = String(j.title || 'День без названия').replace(/[«».]/g, '').trim().split(/\s+/);
  return {
    source,
    title: words.slice(0, 7).join(' '),
    caption: String(j.caption || '').slice(0, 80),
    mood: {
      valence: clamp(m.valence, -1, 1), energy: clamp(m.energy), warmth: clamp(m.warmth),
      tension: clamp(m.tension), nostalgia: clamp(m.nostalgia), social: clamp(m.social), calm: clamp(m.calm),
    },
    time_of_day: j.time_of_day || 'day',
    season: j.season || 'unknown',
    setting: j.setting || 'other',
    keywords: (j.keywords || []).slice(0, 5),
    senses: j.senses || '',
    song: j.song || null,
    photo_notes: j.photo_notes || '',
  };
}

// ——— Офлайн-эвристика: словари образов → оси. Работает без сети, чтобы прототип не падал на демо.
const LEX = [
  [/холод|мороз|снег|зим/i, { warmth: -0.15, season: 'winter' }],
  [/осен|листь|листоп|жёлт|желт/i, { nostalgia: 0.3, season: 'autumn' }],
  [/весн|цвет[её]т|сакур/i, { valence: 0.3, season: 'spring' }],
  [/лет[оа]|жар|пляж|море|солнц/i, { valence: 0.3, energy: 0.2, warmth: 0.3, season: 'summer' }],
  [/какао|чай|плед|уют|дом|кухн|свеч/i, { warmth: 0.4, calm: 0.3 }],
  [/разговар|обнял|вместе|девушк|парн|мам|пап|бабуш|друз|семь/i, { warmth: 0.3, social: 0.4 }],
  [/вечеринк|концерт|танц|толп|праздник|день рождения/i, { energy: 0.5, social: 0.6, valence: 0.4 }],
  [/дедлайн|сдач|срочн|офис|работ|отчёт|отчет|созвон|проект/i, { tension: 0.6, energy: 0.4, calm: -0.4, setting: 'office' }],
  [/ноч|полноч|до утра|не спал/i, { time: 'night', tension: 0.15 }],
  [/вечер|закат/i, { time: 'evening', calm: 0.2 }],
  [/утр|рассвет/i, { time: 'morning', valence: 0.1 }],
  [/парк|лес|пруд|озер|река|гор|пол[ея]/i, { calm: 0.3, setting: 'nature' }],
  [/дожд|туман|серо|пасмур/i, { nostalgia: 0.2, valence: -0.15, calm: 0.15 }],
  [/устал|грус|одинок|тоск|плак/i, { valence: -0.45, energy: -0.2, nostalgia: 0.2 }],
  [/счаст|радост|смеял|кайф|восторг|люблю/i, { valence: 0.5, warmth: 0.2 }],
  [/тишин|тихо|медлен|спокой/i, { calm: 0.5, energy: -0.3 }],
  [/одна\b|один\b|никого|одиноч|сам[аи]? с собой/i, { social: -0.35, warmth: -0.2, calm: 0.15 }],
  [/бежал|спешил|опазд|метро|пробк/i, { energy: 0.3, tension: 0.3 }],
  [/вспомнил|как раньше|детств|старые фото/i, { nostalgia: 0.5 }],
];

function heuristic(input) {
  const t = input.text || '';
  const m = { valence: 0.1, energy: 0.4, warmth: 0.45, tension: 0.15, nostalgia: 0.2, social: 0.2, calm: 0.4 };
  let season = 'unknown', time = 'day', setting = 'other';
  const hits = [];
  for (const [re, eff] of LEX) {
    const found = t.match(re);
    if (!found) continue;
    hits.push(found[0]);
    for (const k in eff) {
      if (k === 'season') season = eff[k];
      else if (k === 'time') { const pr = { night: 3, evening: 2, morning: 1, day: 0 }; if (pr[eff[k]] > pr[time]) time = eff[k]; }
      else if (k === 'setting') setting = eff[k];
      else m[k] += eff[k];
    }
  }
  const af = input.audioFeatures;
  if (af) { m.energy = (m.energy + af.energy) / 2; if (af.mode === 'minor') m.nostalgia += 0.1; }
  const PHRASES = [
    [/день рождения/i, 'день рождения', 'head'], [/дедлайн|сдач/i, 'перед сдачей', 'detail'],
    [/офис/i, 'в офисе', 'place'], [/парк/i, 'в парке', 'place'], [/пруд|озер/i, 'у пруда', 'place'],
    [/мор[еяю]|пляж/i, 'у моря', 'place'], [/лес/i, 'в лесу', 'place'], [/кухн/i, 'на кухне', 'place'],
    [/у мамы|мам/i, 'у мамы', 'place'], [/окн/i, 'у окна', 'place'], [/дом[аеу]?\b/i, 'дома', 'place'],
    [/какао/i, 'и какао', 'detail'], [/чай/i, 'и чай', 'detail'], [/кофе/i, 'и остывший кофе', 'detail'],
    [/дожд/i, 'под дождём', 'detail'], [/снег/i, 'и первый снег', 'detail'], [/старые фото|фотограф/i, 'и старые фото', 'detail'],
    [/танц/i, 'и танцы', 'detail'], [/разговар/i, 'и долгий разговор', 'detail'], [/друз|подруг/i, 'с друзьями', 'detail'],
  ];
  const got = {};
  for (const [re, ph, slot] of PHRASES) if (!got[slot] && re.test(t)) got[slot] = ph;
  const SEASON_ADJ = { autumn: 'Осенний', winter: 'Зимний', spring: 'Весенний', summer: 'Летний' };
  const TIME = { night: 'Ночь', evening: 'Вечер', morning: 'Утро' };
  let head = got.head ? got.head[0].toUpperCase() + got.head.slice(1) : TIME[time] || `${SEASON_ADJ[season] || 'Обычный'} день`;
  let parts = [head, got.place, got.detail].filter(Boolean);
  if (parts.join(' ').split(' ').length < 3) parts.push(m.calm > 0.6 ? 'в тишине' : m.energy > 0.6 ? 'на бегу' : 'без спешки');
  const first = (t.split(/[.!?\n]/)[0] || '').split(/\s+/);
  let caption = '';
  for (const w of first) { if ((caption + ' ' + w).trim().length > 58) break; caption = (caption + ' ' + w).trim(); }
  return {
    title: parts.join(' '),
    caption,
    mood: m, time_of_day: time, season, setting,
    keywords: [...new Set(hits.map(h => h.toLowerCase()))].slice(0, 4),
    senses: '', song: null, photo_notes: '',
  };
}
