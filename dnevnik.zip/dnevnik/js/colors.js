// Цвета и свет фотографий: палитра (k-means), яркость, контраст, «температура» кадра.

export function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0; const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h *= 60;
  }
  return [h, s, l];
}

export function hslToRgb(h, s, l) {
  h = ((h % 360) + 360) % 360 / 360;
  if (s === 0) return [l * 255, l * 255, l * 255];
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const f = t => {
    if (t < 0) t += 1; if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  return [f(h + 1 / 3) * 255, f(h) * 255, f(h - 1 / 3) * 255];
}

export const hsl = (h, s, l, a = 1) =>
  `hsla(${Math.round(((h % 360) + 360) % 360)},${Math.round(Math.max(0, Math.min(1, s)) * 100)}%,${Math.round(Math.max(0, Math.min(1, l)) * 100)}%,${a})`;

export async function loadBitmap(blob) {
  return createImageBitmap(blob);
}

function samplePixels(bmp, size = 96) {
  const k = size / Math.max(bmp.width, bmp.height);
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(bmp.width * k)); c.height = Math.max(1, Math.round(bmp.height * k));
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(bmp, 0, 0, c.width, c.height);
  return ctx.getImageData(0, 0, c.width, c.height).data;
}

// Анализ набора фото → палитра из 5 цветов + метрики света
export async function analyzePhotos(blobs) {
  const px = [];
  let lumSum = 0, lumSq = 0, satSum = 0, warmSum = 0, n = 0;
  for (const b of blobs) {
    const bmp = await loadBitmap(b);
    const d = samplePixels(bmp);
    for (let i = 0; i < d.length; i += 4) {
      const r = d[i], g = d[i + 1], bl = d[i + 2];
      const [h, s, l] = rgbToHsl(r, g, bl);
      lumSum += l; lumSq += l * l; satSum += s; n++;
      // тёплые оттенки (красный–жёлтый) дают +, холодные (голубой–синий) −; вес — насыщенность
      const warm = Math.cos(((h - 35) * Math.PI) / 180);
      warmSum += warm * s;
      if (i % 8 === 0) px.push([r, g, bl]);
    }
  }
  const lum = lumSum / n;
  const contrast = Math.sqrt(Math.max(0, lumSq / n - lum * lum));
  const palette = kmeans(px, 5).map(([r, g, b, w]) => ({ hsl: rgbToHsl(r, g, b), w }));
  palette.sort((a, b) => b.w - a.w);
  return {
    palette, // [{hsl:[h,s,l], w}]
    luminance: lum,
    contrast,
    saturation: satSum / n,
    warmth: Math.max(0, Math.min(1, 0.5 + warmSum / n)),
    count: blobs.length,
  };
}

function kmeans(pts, k, iters = 10) {
  if (pts.length === 0) return [[128, 128, 128, 1]];
  let cent = [];
  for (let i = 0; i < k; i++) cent.push(pts[Math.floor((i + 0.5) * pts.length / k)].slice());
  let assign = new Array(pts.length).fill(0);
  for (let it = 0; it < iters; it++) {
    for (let i = 0; i < pts.length; i++) {
      let best = 0, bd = Infinity;
      for (let c = 0; c < k; c++) {
        const dr = pts[i][0] - cent[c][0], dg = pts[i][1] - cent[c][1], db = pts[i][2] - cent[c][2];
        const dd = dr * dr + dg * dg + db * db;
        if (dd < bd) { bd = dd; best = c; }
      }
      assign[i] = best;
    }
    const sum = Array.from({ length: k }, () => [0, 0, 0, 0]);
    for (let i = 0; i < pts.length; i++) {
      const s = sum[assign[i]]; s[0] += pts[i][0]; s[1] += pts[i][1]; s[2] += pts[i][2]; s[3]++;
    }
    cent = sum.map((s, c) => (s[3] ? [s[0] / s[3], s[1] / s[3], s[2] / s[3]] : cent[c]));
  }
  const counts = new Array(k).fill(0);
  assign.forEach(a => counts[a]++);
  return cent.map((c, i) => [...c, counts[i] / pts.length]);
}

// Цветокоррекция фото под стиль дня: насыщенность, контраст, тонирование в палитру, подъём теней.
// Делается пиксельно один раз (работает и там, где нет ctx.filter, например в Safari).
export function gradeImage(bmp, maxSide, g) {
  const k = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(bmp, 0, 0, c.width, c.height);
  const img = ctx.getImageData(0, 0, c.width, c.height);
  const d = img.data;
  const [sr, sg, sb] = hslToRgb(g.shadowHue, g.tintSat, 0.25);
  const [hr, hg, hb] = hslToRgb(g.highlightHue, g.tintSat, 0.75);
  for (let i = 0; i < d.length; i += 4) {
    let r = d[i] / 255, gg = d[i + 1] / 255, b = d[i + 2] / 255;
    const l = 0.299 * r + 0.587 * gg + 0.114 * b;
    // насыщенность
    r = l + (r - l) * g.saturation; gg = l + (gg - l) * g.saturation; b = l + (b - l) * g.saturation;
    // контраст
    r = (r - 0.5) * g.contrast + 0.5; gg = (gg - 0.5) * g.contrast + 0.5; b = (b - 0.5) * g.contrast + 0.5;
    // подъём чёрного (плёночный «молочный» чёрный)
    r = g.lift + r * (1 - g.lift); gg = g.lift + gg * (1 - g.lift); b = g.lift + b * (1 - g.lift);
    // split-toning: тени в один оттенок, света в другой
    const t = Math.max(0, Math.min(1, l));
    const tr = (sr * (1 - t) + hr * t) / 255, tg = (sg * (1 - t) + hg * t) / 255, tb = (sb * (1 - t) + hb * t) / 255;
    r = r * (1 - g.tint) + (r * tr * 2) * g.tint;
    gg = gg * (1 - g.tint) + (gg * tg * 2) * g.tint;
    b = b * (1 - g.tint) + (b * tb * 2) * g.tint;
    // яркость
    d[i] = Math.max(0, Math.min(255, r * 255 * g.exposure));
    d[i + 1] = Math.max(0, Math.min(255, gg * 255 * g.exposure));
    d[i + 2] = Math.max(0, Math.min(255, b * 255 * g.exposure));
  }
  ctx.putImageData(img, 0, 0);
  return c;
}
