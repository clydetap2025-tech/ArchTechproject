import { saveDay, getDay, listDays, deleteDay } from './db.js';
import { analyzeDay, getSettings, setSettings } from './analyze.js';
import { analyzePhotos, hsl } from './colors.js';
import { analyzeAudio, linkMeta, embedFor } from './audio.js';
import { buildStyle, TECHNIQUES } from './rules.js';
import { DayRenderer, loadFonts, W, H } from './render.js';
import { synthesize, speakFallback } from './voice.js';
import { makeZip } from './zip.js';

const view = document.getElementById('view');
const esc = s => String(s ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const fmtDate = d => new Intl.DateTimeFormat('ru', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(d + 'T12:00:00')).replace(/\s?г\.?$/, '');
const todayISO = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };

let player = null; // активный проигрыватель дня
function stopPlayer() { if (player) { player.destroy(); player = null; } }

// ——— Роутинг
async function route() {
  stopPlayer();
  const h = location.hash.slice(1) || 'feed';
  document.querySelectorAll('[data-nav]').forEach(a => a.classList.toggle('active', h.startsWith(a.dataset.nav)));
  if (h === 'new') return renderNew();
  if (h.startsWith('day/')) return renderDay(h.slice(4));
  return renderFeed();
}
window.addEventListener('hashchange', route);

// ——— Архив
async function renderFeed(mode = 'grid') {
  const days = await listDays();
  if (!days.length) {
    view.innerHTML = `
      <h1>Ваш дневник пока пуст</h1>
      <div class="empty">
        <p>Расскажите, как прошёл день, приложите фото и песню — дневник соберёт из этого страницу, которая через год напомнит, как он ощущался.</p>
        <a href="#new" class="primary" style="display:inline-block;text-decoration:none">Записать первый день</a>
      </div>`;
    return;
  }
  view.innerHTML = `
    <div class="feed-head">
      <div><div class="meta">${days.length} ${plural(days.length, ['день', 'дня', 'дней'])} в дневнике</div><h1>Архив</h1></div>
      <div class="seg" role="group" aria-label="Вид архива">
        <button data-m="grid" class="${mode === 'grid' ? 'on' : ''}">Папки</button>
        <button data-m="strip" class="${mode === 'strip' ? 'on' : ''}">Лента</button>
      </div>
    </div>
    <div class="grid ${mode === 'strip' ? 'strip' : ''}">
      ${days.map(d => `
        <a class="card" href="#day/${d.id}">
          <div class="thumb"><img src="${d.thumb}" alt="${esc(d.analysis.title)}" loading="lazy"></div>
          <div class="folder"><b>${esc(d.analysis.title)}</b></div>
          <div class="meta">${fmtDate(d.date)}</div>
        </a>`).join('')}
    </div>`;
  view.querySelectorAll('.seg button').forEach(b => b.onclick = () => renderFeed(b.dataset.m));
}

const plural = (n, f) => f[n % 10 === 1 && n % 100 !== 11 ? 0 : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 1 : 2];

// ——— Новый день
function renderNew() {
  view.innerHTML = `
    <div class="meta">Новая запись</div>
    <h1>Как прошёл день?</h1>
    <p class="lede">Пишите так, как рассказали бы близкому другу: погода, свет, запахи, звуки, кто был рядом, мелочи, которые запомнились.</p>
    <form class="form" id="f">
      <div class="field"><label for="date">Дата</label><input type="date" id="date" value="${todayISO()}" required></div>
      <div class="field"><label for="text">Запись</label>
        <textarea id="text" required placeholder="Гуляли по парку, всё в жёлтых листьях, было холодно, но мы пили какао и долго разговаривали…"></textarea>
      </div>
      <div class="field"><span class="label">Фото дня <small>одно или несколько</small></span>
        <label class="drop" id="drop"><input type="file" id="photos" accept="image/*" multiple><span class="ph">＋ Выбрать фото</span></label>
      </div>
      <div class="field"><span class="label">Песня дня</span>
        <div class="song">
          <input type="url" id="link" placeholder="Ссылка: YouTube, Spotify, Яндекс Музыка">
          <div class="or">или</div>
          <label class="filebtn"><input type="file" id="audio" accept="audio/*"><span id="audioName">♪ Свой аудиофайл (останется на устройстве)</span></label>
          <input type="text" id="songMeta" placeholder="Исполнитель — название (если ссылка не распознается)">
          <div class="tip">По файлу дневник сам измерит темп, энергию и лад. По ссылке — узнает песню по названию.</div>
        </div>
      </div>
      <button class="primary" id="go">Собрать воспоминание</button>
      <div class="progress" id="prog" aria-live="polite"></div>
    </form>`;
  const photosIn = view.querySelector('#photos'), drop = view.querySelector('#drop');
  photosIn.onchange = () => {
    drop.querySelectorAll('.pv').forEach(x => x.remove());
    [...photosIn.files].forEach(f => { const im = document.createElement('img'); im.className = 'pv'; im.src = URL.createObjectURL(f); drop.insertBefore(im, drop.querySelector('.ph')); });
    drop.querySelector('.ph').textContent = photosIn.files.length ? 'Заменить' : '＋ Выбрать фото';
  };
  const audioIn = view.querySelector('#audio');
  audioIn.onchange = () => { view.querySelector('#audioName').textContent = audioIn.files[0] ? `♪ ${audioIn.files[0].name}` : '♪ Свой аудиофайл'; };
  view.querySelector('#f').onsubmit = async e => {
    e.preventDefault();
    const input = {
      date: view.querySelector('#date').value,
      text: view.querySelector('#text').value.trim(),
      photos: [...photosIn.files],
      audio: audioIn.files[0] || null,
      link: view.querySelector('#link').value.trim(),
      songMeta: view.querySelector('#songMeta').value.trim(),
    };
    const prog = view.querySelector('#prog'), btn = view.querySelector('#go');
    if (!input.photos.length) { prog.innerHTML = '<span class="err">Добавьте хотя бы одно фото этого дня.</span>'; return; }
    if (!input.audio && !input.link && !input.songMeta) { prog.innerHTML = '<span class="err">Добавьте песню: ссылку, файл или хотя бы название.</span>'; return; }
    btn.disabled = true;
    try {
      const day = await createDay(input, msg => { prog.textContent += (prog.textContent ? '\n' : '') + msg; });
      location.hash = `#day/${day.id}`;
    } catch (err) {
      console.error(err);
      prog.innerHTML += `\n<span class="err">Не получилось собрать день: ${esc(err.message)}. Попробуйте ещё раз — запись не потеряна.</span>`;
      btn.disabled = false;
    }
  };
}

export async function createDay(input, log = () => {}) {
  let audioFeatures = null;
  if (input.audio) {
    log('Слушаю песню: темп, энергия, лад…');
    try { audioFeatures = await analyzeAudio(input.audio); log(`  ${audioFeatures.bpm} BPM, ${audioFeatures.key}, энергия ${Math.round(audioFeatures.energy * 100)}%`); }
    catch (e) { log('  не удалось разобрать файл, беру описание песни'); }
  }
  let songMeta = input.songMeta;
  if (!songMeta && input.link) { songMeta = await linkMeta(input.link); }
  if (!songMeta && input.audio) songMeta = input.audio.name.replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ');
  log('Смотрю на фото: цвета и свет…');
  const photoStats = await analyzePhotos(input.photos);
  log('Читаю запись…');
  const analysis = await analyzeDay({ ...input, songMeta, audioFeatures });
  log(`  «${analysis.title}»${analysis.source === 'offline' ? ' (офлайн-правила)' : ''}`);
  const style = buildStyle({ analysis, photo: photoStats, audio: audioFeatures, date: input.date, songMeta });
  log(`Собираю страницу: ${TECHNIQUES[style.technique].name}…`);
  const days = await listDays();
  const day = {
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    number: days.length + 1,
    date: input.date, created: new Date().toISOString(),
    text: input.text,
    photos: input.photos.map(f => new Blob([f], { type: f.type })),
    audio: input.audio ? new Blob([input.audio], { type: input.audio.type }) : null,
    audioName: input.audio?.name || '',
    songLink: input.link, songMeta,
    audioFeatures, photoStats, analysis, style,
    voice: null,
  };
  day.thumb = await renderThumb(day);
  await saveDay(day);
  return day;
}

async function renderThumb(day) {
  await loadFonts();
  const cv = document.createElement('canvas');
  const bitmaps = await Promise.all(day.photos.map(b => createImageBitmap(b)));
  const r = new DayRenderer(cv, day, bitmaps);
  await r.prepare();
  r.draw(day.style.slideSec * 0.4);
  const t = document.createElement('canvas'); t.width = 432; t.height = 768;
  t.getContext('2d').drawImage(cv, 0, 0, t.width, t.height);
  return t.toDataURL('image/jpeg', 0.85);
}

// ——— Страница дня
async function renderDay(id) {
  const day = await getDay(id);
  if (!day) { view.innerHTML = '<p>Такого дня нет. <a href="#feed">В архив</a></p>'; return; }
  const s = day.style, a = day.analysis;
  const embed = embedFor(day.songLink);
  const P = s.palette;
  view.innerHTML = `
    <div class="day">
      <div class="stage">
        <canvas id="cv" width="${W}" height="${H}" aria-label="Воспоминание дня: ${esc(a.title)}"></canvas>
        <div class="controls">
          <button class="main" id="play">▶ Смотреть с музыкой</button>
          <button id="voice">🎙 Озвучка</button>
          <button id="rec">⬇ Видео</button>
          <button id="zip">⬇ Папка</button>
          <button class="danger" id="del">Удалить</button>
        </div>
        ${embed ? `<div class="embed"><iframe src="${embed}" height="${/spotify/.test(embed) ? 152 : 200}" allow="autoplay; encrypted-media" loading="lazy"></iframe></div>` : ''}
        <div class="progress" id="st" aria-live="polite"></div>
      </div>
      <div>
        <section class="panel">
          <div class="meta">Папка дня · ${fmtDate(day.date)} · № ${String(day.number).padStart(3, '0')}</div>
          <h1>${esc(a.title)}</h1>
          <ul class="files">
            <li>запись.txt</li>
            <li>фото × ${day.photos.length}</li>
            <li>песня: ${esc(day.songMeta || day.audioName || day.songLink)}${day.audio ? ' (файл)' : day.songLink ? ' (ссылка)' : ''}</li>
            <li>воспоминание (страница 9:16, видео по кнопке)</li>
            <li id="voiceLi">озвучка: ${day.voice ? 'готова' : 'по кнопке'} — ${esc(s.voice.label)}</li>
          </ul>
        </section>
        <section class="panel">
          <h2>Почему день выглядит так</h2>
          <ul class="why">${s.explain.map(e => `<li><b>${esc(e.rule)}</b><span>${esc(e.because)}</span></li>`).join('')}</ul>
          <div class="swatches" aria-label="Палитра дня">${[P.paper, P.ink, P.accent, P.accent2, ...(P.photo || []).slice(0, 4)].map(x => `<span style="background:${hsl(x[0], x[1], x[2])}"></span>`).join('')}</div>
        </section>
        <section class="panel">
          <h2>Ощущение дня <span class="badge">${a.source === 'openai' ? 'модель' : 'офлайн'}</span></h2>
          <div class="bars">${[['тепло', s.vector.warmth], ['энергия', s.vector.energy], ['напряжение', s.vector.tension], ['ностальгия', s.vector.nostalgia], ['люди рядом', s.vector.social], ['тишина', s.vector.calm], ['настроение', (s.vector.valence + 1) / 2]]
            .map(([k, v]) => `<span>${k}</span><i style="--v:${Math.round(v * 100)}%"></i><span>${Math.round(v * 100)}</span>`).join('')}</div>
          <p class="tip">Это описание атмосферы для оформления, а не оценка состояния человека.</p>
          ${a.senses ? `<p class="tip">Ощущения: ${esc(a.senses)}</p>` : ''}
        </section>
        <section class="panel">
          <h2>Запись</h2>
          <div class="entry">${esc(day.text)}</div>
        </section>
      </div>
    </div>`;

  await loadFonts();
  const bitmaps = await Promise.all(day.photos.map(b => createImageBitmap(b)));
  const cv = view.querySelector('#cv');
  const r = new DayRenderer(cv, day, bitmaps);
  await r.prepare();
  player = new Player(r, day);
  player.start();

  const st = view.querySelector('#st');
  const playBtn = view.querySelector('#play');
  playBtn.onclick = () => {
    const on = player.toggleMusic();
    playBtn.textContent = on ? '❚❚ Пауза' : '▶ Смотреть с музыкой';
    if (!day.audio && on) st.textContent = embed ? 'Включите песню в плеере ниже — ритм страницы уже идёт в её темпе.' : '';
  };
  view.querySelector('#voice').onclick = async () => {
    st.textContent = `Голос: ${s.voice.label}…`;
    if (!day.voice) {
      const blob = await synthesize(day.text, s.voice);
      if (blob) { day.voice = blob; await saveDay(day); view.querySelector('#voiceLi').textContent = `озвучка: готова — ${s.voice.label}`; }
    }
    if (day.voice) { player.playVoice(day.voice); st.textContent = `Озвучка: ${s.voice.label}`; }
    else { speakFallback(day.text, s.voice); st.textContent = 'Озвучка голосом браузера (сервер озвучки недоступен).'; }
  };
  view.querySelector('#rec').onclick = async () => {
    st.textContent = 'Записываю видео…';
    try {
      const blob = await player.record(s => st.textContent = `Записываю видео… ${s} с`);
      download(blob, `${a.title}.${blob.type.includes('mp4') ? 'mp4' : 'webm'}`);
      st.textContent = day.audio ? 'Видео готово.' : 'Видео готово (без звука: песня по ссылке не встраивается в файл).';
    } catch (e) { st.textContent = 'Браузер не умеет записывать видео с canvas.'; }
  };
  view.querySelector('#zip').onclick = async () => {
    const files = [
      { name: `${a.title}/запись.txt`, data: `${fmtDate(day.date)}\n\n${day.text}\n` },
      ...day.photos.map((p, i) => ({ name: `${a.title}/фото_${i + 1}.${(p.type.split('/')[1] || 'jpg').replace('jpeg', 'jpg')}`, data: p })),
      { name: `${a.title}/воспоминание.jpg`, data: await (await fetch(day.thumb)).blob() },
      { name: `${a.title}/правила.json`, data: JSON.stringify({ title: a.title, technique: TECHNIQUES[s.technique].name, explain: s.explain, mood: s.vector }, null, 2) },
    ];
    if (day.audio) files.push({ name: `${a.title}/${day.audioName || 'песня.mp3'}`, data: day.audio });
    else files.push({ name: `${a.title}/песня.txt`, data: `${day.songMeta || ''}\n${day.songLink || ''}\n` });
    if (day.voice) files.push({ name: `${a.title}/озвучка.mp3`, data: day.voice });
    download(await makeZip(files), `${a.title}.zip`);
  };
  const del = view.querySelector('#del');
  del.onclick = async () => {
    if (!del.dataset.sure) { del.dataset.sure = 1; del.textContent = `Удалить «${a.title}»?`; return; }
    await deleteDay(day.id); location.hash = '#feed';
  };
}

function download(blob, name) {
  const u = URL.createObjectURL(blob);
  const l = document.createElement('a'); l.href = u; l.download = name; document.body.appendChild(l); l.click(); l.remove();
  setTimeout(() => URL.revokeObjectURL(u), 4000);
}

// ——— Проигрыватель: анимация + музыка + анализатор + запись видео
class Player {
  constructor(renderer, day) {
    this.r = renderer; this.day = day;
    this.t0 = performance.now(); this.raf = 0; this.alive = true;
    this.audioEl = null; this.ac = null;
  }
  start() {
    const loop = now => {
      if (!this.alive) return;
      const t = this.audioEl && !this.audioEl.paused ? this.audioEl.currentTime : Math.max(0, (now - this.t0) / 1000);
      this.r.draw(t);
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }
  ensureAudio() {
    if (this.audioEl || !this.day.audio) return;
    this.audioEl = new Audio(URL.createObjectURL(this.day.audio));
    this.audioEl.loop = true;
    try {
      this.ac = new (window.AudioContext || window.webkitAudioContext)();
      const src = this.ac.createMediaElementSource(this.audioEl);
      const an = this.ac.createAnalyser(); an.fftSize = 256; an.smoothingTimeConstant = 0.6;
      this.dest = this.ac.createMediaStreamDestination();
      src.connect(an); an.connect(this.ac.destination); src.connect(this.dest);
      this.r.attachAnalyser(an);
    } catch (e) { console.warn(e); }
  }
  toggleMusic() {
    if (!this.day.audio) { this.t0 = performance.now(); this._on = !this._on; return this._on; }
    this.ensureAudio();
    this.ac?.resume();
    if (this.audioEl.paused) { this.audioEl.play(); return true; }
    this.audioEl.pause(); return false;
  }
  playVoice(blob) {
    if (this.voiceEl) this.voiceEl.pause();
    this.voiceEl = new Audio(URL.createObjectURL(blob));
    if (this.audioEl && !this.audioEl.paused) this.audioEl.volume = 0.35; // музыка уходит под голос
    this.voiceEl.onended = () => { if (this.audioEl) this.audioEl.volume = 1; };
    this.voiceEl.play();
  }
  async record(onTick) {
    const s = this.day.style;
    const dur = Math.round(Math.min(30, Math.max(15, s.slideSec * Math.max(2, this.day.photos.length) * 1.5)));
    const stream = this.r.cv.captureStream(30);
    if (this.day.audio) {
      this.ensureAudio(); await this.ac.resume();
      this.dest.stream.getAudioTracks().forEach(t => stream.addTrack(t));
      this.audioEl.currentTime = 0; await this.audioEl.play();
    } else this.t0 = performance.now();
    const types = ['video/mp4;codecs=avc1', 'video/webm;codecs=vp9,opus', 'video/webm'];
    const mimeType = types.find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t));
    const rec = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 8e6 });
    const chunks = [];
    rec.ondataavailable = e => e.data.size && chunks.push(e.data);
    const done = new Promise(res => rec.onstop = res);
    rec.start(500);
    for (let i = 1; i <= dur; i++) { await new Promise(r => setTimeout(r, 1000)); onTick?.(i); }
    rec.stop(); await done;
    return new Blob(chunks, { type: mimeType.split(';')[0] });
  }
  destroy() {
    this.alive = false; cancelAnimationFrame(this.raf);
    this.audioEl?.pause(); this.voiceEl?.pause(); this.ac?.close();
    if ('speechSynthesis' in window) speechSynthesis.cancel();
  }
}

// ——— Настройки
const dlg = document.getElementById('settings');
document.getElementById('settingsBtn').onclick = () => {
  const s = getSettings();
  document.getElementById('setKey').value = s.key || '';
  document.getElementById('setModel').value = s.model || '';
  dlg.showModal();
};
dlg.addEventListener('close', () => {
  if (dlg.returnValue === 'save') setSettings({ key: document.getElementById('setKey').value.trim(), model: document.getElementById('setModel').value.trim() });
});

window.__diary = { createDay }; // для демо-скриптов и тестов
route();
