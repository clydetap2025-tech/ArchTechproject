// Озвучка записи: OpenAI gpt-4o-mini-tts (голос и манера из правил) → запасной вариант — голос браузера.
import { getSettings } from './analyze.js';

export async function synthesize(text, v) {
  const body = { text, voice: v.voice, instructions: v.instructions, speed: v.speed };
  try {
    const r = await fetch('api/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (r.ok && (r.headers.get('content-type') || '').includes('audio')) return await r.blob();
  } catch {}
  const { key } = getSettings();
  if (key) {
    try {
      const r = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
        body: JSON.stringify({ model: 'gpt-4o-mini-tts', input: text.slice(0, 3500), voice: v.voice, instructions: v.instructions, speed: v.speed, response_format: 'mp3' }),
      });
      if (r.ok) return await r.blob();
    } catch {}
  }
  return null;
}

export function speakFallback(text, v) {
  if (!('speechSynthesis' in window)) return null;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = 'ru-RU'; u.rate = v.rate; u.pitch = v.pitch;
  const ru = speechSynthesis.getVoices().find(x => x.lang.startsWith('ru'));
  if (ru) u.voice = ru;
  speechSynthesis.speak(u);
  return u;
}
