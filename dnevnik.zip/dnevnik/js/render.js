// Рендер «страницы дня» 9:16 на canvas.
// ПОСТОЯННОЕ (одинаково для всех дней): формат 1080×1920, поля, шапка с датой и номером, окно фото,
//   место названия (антиква), рукописная подпись, подвал с песней. Шрифты всегда одни и те же.
// ПЕРЕМЕННОЕ (из правил rules.js): палитра, обработка фото, приём, ритм, переходы, зерно, воздух, пульс.
import { gradeImage, hsl } from './colors.js';
import { rng } from './rules.js';

export const W = 1080, H = 1920, M = 72;
const FONT_TITLE = '"Cormorant Garamond", "Times New Roman", serif';
const FONT_MONO = '"JetBrains Mono", ui-monospace, monospace';
const FONT_HAND = '"Caveat", "Segoe Script", cursive';

export async function loadFonts() {
  try {
    await Promise.all([
      document.fonts.load(`500 80px "Cormorant Garamond"`, 'Аа'),
      document.fonts.load(`italic 400 80px "Cormorant Garamond"`, 'Аа'),
      document.fonts.load(`700 80px "Cormorant Garamond"`, 'Аа'),
      document.fonts.load(`400 30px "JetBrains Mono"`, 'Аа'),
      document.fonts.load(`500 56px "Caveat"`, 'Аа'),
    ]);
  } catch {}
}

const c = (arr, a = 1) => hsl(arr[0], arr[1], arr[2], a);

export class DayRenderer {
  constructor(canvas, day, bitmaps) {
    this.cv = canvas;
    this.cv.width = W; this.cv.height = H;
    this.ctx = canvas.getContext('2d');
    this.day = day;
    this.s = day.style;
    this.bitmaps = bitmaps;
    this.analyser = null;
    this.freq = null;
  }

  async prepare() {
    const s = this.s;
    const r = rng(s.seed);
    // окно фото: высота зависит от «воздуха»
    const maxW = W - 2 * M, maxH = 1180;
    let scale = 1 - s.air * 0.28;
    if (s.technique === 'ma') scale = 0.6;
    const w = Math.round(maxW * scale), h = Math.round(maxH * scale);
    let x = Math.round((W - w) / 2);
    if (s.technique === 'ma') x = r() < 0.5 ? M : W - M - w;
    const y = Math.round(178 + (maxH - h) * (s.technique === 'ma' ? 0.22 : 0.4));
    this.win = { x, y, w, h };

    const maxSide = s.technique === 'collage' ? 760 : 1200;
    this.photos = this.bitmaps.map(b => gradeImage(b, maxSide, s.grade));
    if (s.technique === 'monet') this.painted = this.photos.map(p => paint(p, w, h, s, rng(s.seed + 7)));
    this.grainFrames = Array.from({ length: 4 }, (_, i) => noiseCanvas(540, 960, rng(s.seed + i)));
    this.paperTex = noiseCanvas(540, 960, rng(s.seed + 99), 0.5);
    this.shapes = makeShapes(s, rng(s.seed + 3));
    this.collage = makeCollage(this.photos, this.win, rng(s.seed + 5));
    this.focus = Array.from({ length: 32 }, () => [r() - 0.5, r() - 0.5, r() < 0.5 ? 1 : -1]);
    const d = new Date(this.day.date + 'T12:00:00');
    this.dateStr = new Intl.DateTimeFormat('ru', { day: 'numeric', month: 'long', year: 'numeric' }).format(d).replace(/\s?г\.?$/, '').toUpperCase();
    this.weekday = new Intl.DateTimeFormat('ru', { weekday: 'short' }).format(d).toUpperCase();
    this.stamp = `'${String(d.getFullYear()).slice(2)} ${String(d.getMonth() + 1).padStart(2, ' ')} ${String(d.getDate()).padStart(2, '0')}`;
  }

  attachAnalyser(an) {
    this.analyser = an;
    this.freq = an ? new Uint8Array(an.frequencyBinCount) : null;
  }

  // уровень «удара»: живой из аудио или синтетический по BPM
  beat(t) {
    if (this.analyser) {
      this.analyser.getByteFrequencyData(this.freq);
      let s = 0; const n = Math.min(24, this.freq.length);
      for (let i = 1; i < n; i++) s += this.freq[i];
      const lvl = s / (n - 1) / 255;
      this._lvl = Math.max(lvl, (this._lvl || 0) * 0.86);
      return Math.min(1, this._lvl * 1.4);
    }
    const ph = (t * this.s.vector.bpm / 60) % 1;
    return Math.exp(-ph * 5);
  }

  draw(t) {
    // ошибка в одном кадре не должна ломать состояние контекста в следующих
    this.ctx.save();
    try { this._draw(Math.max(0, t || 0)); } finally { this.ctx.restore(); }
  }

  _draw(t) {
    const { ctx, s, win } = this;
    const b = this.beat(t) * s.pulse;
    const n = Math.max(1, this.photos.length);
    const idx = Math.floor(t / s.slideSec);
    const p = (t % s.slideSec) / s.slideSec;

    // фон-бумага (постоянный приём, переменный цвет)
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    ctx.fillStyle = c(s.palette.paper);
    ctx.fillRect(0, 0, W, H);
    ctx.globalAlpha = s.dark ? 0.05 : 0.07;
    ctx.globalCompositeOperation = s.dark ? 'screen' : 'multiply';
    ctx.drawImage(this.paperTex, 0, 0, W, H);
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';

    if (s.technique === 'kandinsky') this.drawKandinskyBack(t, idx, b);

    // фото
    ctx.save();
    if (s.technique === 'collage') this.drawCollage(t, idx, p, b);
    else {
      const jitter = s.technique === 'film' ? Math.round(Math.sin(t * 23) * 1.5) : 0;
      ctx.beginPath(); ctx.rect(win.x, win.y + jitter, win.w, win.h); ctx.clip();
      const fade = s.transition === 'cut' ? 0 : s.transition === 'long' ? 0.45 : 0.25;
      this.drawSlide(idx % n, idx, p, 1, jitter, b);
      if (fade && p > 1 - fade && n > 0) {
        const a = (p - (1 - fade)) / fade;
        this.drawSlide((idx + 1) % n, idx + 1, 0, ease(a), jitter, b);
      }
      if (s.technique === 'film' || s.secondary === 'film') this.drawFilm(t);
      if (s.technique === 'monet' || s.secondary === 'monet') this.drawShimmer(t);
    }
    ctx.restore();

    if (s.technique === 'kandinsky' || s.secondary === 'kandinsky') this.drawKandinskyFront(t, idx, b, s.technique === 'kandinsky' ? 1 : 0.35);
    if (s.technique === 'ma' || s.secondary === 'ma') this.drawMa(t, s.technique === 'ma' ? 1 : 0.5);
    if (s.secondary === 'collage') this.drawTape();
    if (s.transition === 'cut' && p < 0.06) { // вспышка на склейке
      ctx.fillStyle = c(s.palette.accent, 0.12 * (1 - p / 0.06));
      ctx.fillRect(win.x, win.y, win.w, win.h);
    }

    this.drawConstants(t, b);

    // зерно поверх всего
    if (s.grain > 0.01) {
      ctx.globalAlpha = s.grain;
      ctx.globalCompositeOperation = 'overlay';
      ctx.drawImage(this.grainFrames[Math.floor(t * 12) % 4], 0, 0, W, H);
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    }
  }

  drawSlide(i, slideNo, p, alpha, jitter, b) {
    const { ctx, s, win } = this;
    const img = this.painted ? this.painted[i] : this.photos[i];
    if (!img) return;
    const f = this.focus[Math.abs(slideNo) % this.focus.length];
    const kb = (s.transition === 'cut' ? 0.035 : 0.07) + (s.technique === 'ma' ? -0.03 : 0);
    const zoom = 1.04 + kb * (f[2] > 0 ? p : 1 - p) + b * 0.015;
    const k = Math.max(win.w / img.width, win.h / img.height) * zoom;
    const dw = img.width * k, dh = img.height * k;
    const dx = win.x + (win.w - dw) / 2 + f[0] * (dw - win.w) * 0.8;
    const dy = win.y + jitter + (win.h - dh) / 2 + f[1] * (dh - win.h) * 0.8;
    ctx.globalAlpha = alpha;
    ctx.drawImage(img, dx, dy, dw, dh);
    ctx.globalAlpha = 1;
  }

  drawShimmer(t) {
    // мерцающие пятна света, как блики на воде у Моне
    const { ctx, win, s } = this;
    ctx.globalCompositeOperation = 'soft-light';
    for (let i = 0; i < 4; i++) {
      const x = win.x + win.w * (0.5 + 0.4 * Math.sin(t * 0.13 + i * 1.7));
      const y = win.y + win.h * (0.5 + 0.4 * Math.cos(t * 0.11 + i * 2.3));
      const r = win.w * (0.35 + 0.1 * Math.sin(t * 0.3 + i));
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, hsl(s.palette.accent[0] + 15, 0.8, 0.8, 0.5));
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.fillRect(win.x, win.y, win.w, win.h);
    }
    ctx.globalCompositeOperation = 'source-over';
  }

  drawFilm(t) {
    const { ctx, win } = this;
    // засветка, медленно гуляющая по краю
    ctx.globalCompositeOperation = 'screen';
    const lx = win.x + win.w * (0.9 + 0.15 * Math.sin(t * 0.21));
    const ly = win.y + win.h * (0.2 + 0.2 * Math.sin(t * 0.17));
    const g = ctx.createRadialGradient(lx, ly, 0, lx, ly, win.w * 0.7);
    g.addColorStop(0, 'rgba(255,120,40,0.45)');
    g.addColorStop(0.5, 'rgba(255,60,30,0.12)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(win.x, win.y, win.w, win.h);
    ctx.globalCompositeOperation = 'source-over';
    // виньетка
    const v = ctx.createRadialGradient(win.x + win.w / 2, win.y + win.h / 2, win.w * 0.35, win.x + win.w / 2, win.y + win.h / 2, win.w * 0.85);
    v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.45)');
    ctx.fillStyle = v; ctx.fillRect(win.x, win.y, win.w, win.h);
    // дата-впечатка, как на плёночной мыльнице
    ctx.font = `500 40px ${FONT_MONO}`;
    ctx.textAlign = 'right';
    ctx.shadowColor = 'rgba(255,110,30,0.9)'; ctx.shadowBlur = 14;
    ctx.fillStyle = `rgba(255,150,60,${0.85 + 0.1 * Math.sin(t * 40)})`;
    ctx.fillText(this.stamp, win.x + win.w - 40, win.y + win.h - 40);
    ctx.shadowBlur = 0; ctx.textAlign = 'left';
  }

  drawKandinskyBack(t, idx, b) {
    // тонкая сетка — жёсткий каркас напряжённого дня
    const { ctx, s } = this;
    ctx.strokeStyle = c(s.palette.ink, 0.08); ctx.lineWidth = 1;
    for (let x = M; x <= W - M; x += (W - 2 * M) / 12) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
    for (let y = 0; y <= H; y += 78) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
  }

  drawKandinskyFront(t, idx, b, k) {
    const { ctx, s, shapes } = this;
    const r = rng(s.seed + idx * 31); // композиция перестраивается на каждой склейке
    ctx.save();
    ctx.beginPath(); ctx.rect(0, 140, W, this.win.y + this.win.h + 50 - 140); ctx.clip(); // название остаётся читаемым
    ctx.globalCompositeOperation = s.dark ? 'screen' : 'multiply';
    for (const ci of shapes.circles) {
      const rad = ci.r * (1 + b * 0.12) * (0.9 + r() * 0.2);
      const cx = ci.x + (r() - 0.5) * 60, cy = ci.y + (r() - 0.5) * 60;
      for (let ring = ci.rings; ring >= 1; ring--) {
        ctx.beginPath(); ctx.arc(cx, cy, rad * ring / ci.rings, 0, Math.PI * 2);
        ctx.fillStyle = c(ring % 2 ? s.palette[ci.col] : s.palette.paper, (ring % 2 ? 0.75 : 0.6) * k);
        ctx.fill();
      }
    }
    ctx.globalCompositeOperation = 'source-over';
    ctx.strokeStyle = c(s.palette.ink, 0.9 * k);
    for (const ln of shapes.lines) {
      ctx.lineWidth = ln.w * (1 + b * 0.5);
      const off = (r() - 0.5) * 80;
      ctx.beginPath(); ctx.moveTo(ln.x1 + off, ln.y1); ctx.lineTo(ln.x2 + off, ln.y2); ctx.stroke();
    }
    for (const tr of shapes.tris) {
      ctx.fillStyle = c(s.palette[tr.col], 0.85 * k);
      ctx.beginPath(); ctx.moveTo(tr.p[0], tr.p[1]); ctx.lineTo(tr.p[2], tr.p[3]); ctx.lineTo(tr.p[4], tr.p[5]); ctx.closePath(); ctx.fill();
    }
    // шахматный блок
    const cb = shapes.checker;
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
      if ((i + j + idx) % 2) continue;
      ctx.fillStyle = c(s.palette.ink, 0.85 * k);
      ctx.fillRect(cb.x + i * cb.s, cb.y + j * cb.s, cb.s, cb.s);
    }
    ctx.restore();
  }

  drawMa(t, k) {
    const { ctx, s, win } = this;
    const sunX = win.x + win.w / 2 < W / 2 ? W - M - 110 : M + 110;
    const sunY = win.y + 150 + Math.sin(t * 0.2) * 6;
    ctx.fillStyle = c(s.palette.accent, 0.9 * k);
    ctx.beginPath(); ctx.arc(sunX, sunY, 64, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = c(s.palette.ink, 0.5 * k); ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(M, win.y + win.h + 70); ctx.lineTo(W - M, win.y + win.h + 70); ctx.stroke();
    // вертикальная строка-образ
    const word = (this.day.analysis.keywords[0] || '').toUpperCase();
    if (word && k > 0.6) {
      ctx.font = `400 34px ${FONT_TITLE}`; ctx.fillStyle = c(s.palette.ink, 0.7); ctx.textAlign = 'center';
      [...word].slice(0, 12).forEach((ch, i) => ctx.fillText(ch, sunX, sunY + 140 + i * 44));
      ctx.textAlign = 'left';
    }
  }

  drawCollage(t, idx, p, b) {
    const { ctx, s } = this;
    const cards = this.collage;
    const n = this.photos.length;
    const top = idx % n; // верхняя карточка меняется на каждой склейке
    const order = cards.map((_, i) => (i + top + 1) % n);
    order.forEach((pi, k) => {
      const cd = cards[pi];
      const isTop = k === order.length - 1;
      const img = this.photos[pi];
      const pop = isTop ? 1 + 0.04 * Math.max(0, 1 - p * 6) + b * 0.02 : 1;
      ctx.save();
      ctx.translate(cd.x, cd.y);
      ctx.rotate(cd.rot + Math.sin(t * 2 + pi) * 0.004 * (1 + b * 4));
      ctx.scale(pop, pop);
      const w = cd.w, h = w * img.height / img.width;
      ctx.shadowColor = 'rgba(0,0,0,0.25)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 8;
      ctx.fillStyle = s.dark ? '#e9e4d8' : '#fffdf7';
      ctx.fillRect(-w / 2 - 18, -h / 2 - 18, w + 36, h + 70);
      ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
      ctx.drawImage(img, -w / 2, -h / 2, w, h);
      ctx.fillStyle = c(s.palette.accent, 0.55);
      ctx.save(); ctx.translate(-w / 2 + 10, -h / 2 - 10); ctx.rotate(-0.6); ctx.fillRect(-60, -16, 120, 32); ctx.restore();
      ctx.save(); ctx.translate(w / 2 - 10, -h / 2 - 10); ctx.rotate(0.6); ctx.fillRect(-60, -16, 120, 32); ctx.restore();
      ctx.restore();
    });
    // наклейки-слова, как на ленточном принтере
    ctx.font = `500 30px ${FONT_MONO}`;
    this.day.analysis.keywords.slice(0, 3).forEach((kw, i) => {
      const lb = this.collage.labels[i];
      const text = ` ${kw.toUpperCase()} `;
      const tw = ctx.measureText(text).width;
      ctx.save(); ctx.translate(lb.x, lb.y); ctx.rotate(lb.rot);
      ctx.fillStyle = c(s.palette.ink); ctx.fillRect(-tw / 2, -26, tw, 44);
      ctx.fillStyle = c(s.palette.paper); ctx.textAlign = 'center'; ctx.fillText(text, 0, 6);
      ctx.restore();
    });
    ctx.textAlign = 'left';
  }

  drawTape() {
    const { ctx, s, win } = this;
    ctx.fillStyle = c(s.palette.accent, 0.5);
    [[win.x + 20, win.y + 4, -0.5], [win.x + win.w - 20, win.y + 4, 0.5]].forEach(([x, y, r]) => {
      ctx.save(); ctx.translate(x, y); ctx.rotate(r); ctx.fillRect(-70, -18, 140, 36); ctx.restore();
    });
  }

  drawConstants(t, b) {
    const { ctx, s, day, win } = this;
    const ink = c(s.palette.ink), inkSoft = c(s.palette.ink, 0.6);
    // шапка
    ctx.fillStyle = ink; ctx.font = `400 28px ${FONT_MONO}`; ctx.textBaseline = 'alphabetic';
    ctx.fillText(`${this.dateStr} · ${this.weekday}`, M, 108);
    ctx.textAlign = 'right'; ctx.fillStyle = inkSoft;
    ctx.fillText(`№ ${String(day.number || 1).padStart(3, '0')}`, W - M, 108);
    ctx.textAlign = 'left';
    ctx.fillStyle = c(s.palette.ink, 0.35); ctx.fillRect(M, 132, W - 2 * M, 2);

    // название дня
    const T = s.type;
    const size = 86;
    ctx.fillStyle = ink;
    ctx.font = `${T.italic ? 'italic ' : ''}${T.titleWeight} ${size}px ${FONT_TITLE}`;
    if ('letterSpacing' in ctx) ctx.letterSpacing = `${T.tracking * size}px`;
    const title = T.upper ? day.analysis.title.toUpperCase() : day.analysis.title;
    const lines = wrap(ctx, title, W - 2 * M, 2);
    const titleY = Math.max(win.y + win.h + 120, 1450);
    lines.forEach((ln, i) => ctx.fillText(ln, M, titleY + i * size * 1.02));
    if ('letterSpacing' in ctx) ctx.letterSpacing = '0px';

    // рукописная подпись
    if (day.analysis.caption) {
      ctx.save();
      ctx.translate(M + 6, titleY + lines.length * size * 1.02 + 54);
      ctx.rotate(-0.025);
      ctx.font = `500 54px ${FONT_HAND}`;
      ctx.fillStyle = c(s.palette.accent);
      const capLines = wrap(ctx, day.analysis.caption, W - 2 * M - 20, 2);
      capLines.forEach((ln, i) => ctx.fillText(ln, 0, i * 58));
      ctx.restore();
    }

    // подвал: песня + индикатор долей
    ctx.fillStyle = c(s.palette.ink, 0.35); ctx.fillRect(M, H - 128, W - 2 * M, 2);
    ctx.font = `400 24px ${FONT_MONO}`; ctx.fillStyle = inkSoft;
    const song = day.songMeta ? `♪ ${day.songMeta}` : '♪';
    ctx.fillText(ellipsize(ctx, song, W - 2 * M - 220), M, H - 82);
    // 12 полос: высота от удара и номера доли
    const ph = Math.floor(t * s.vector.bpm / 60);
    for (let i = 0; i < 12; i++) {
      const on = (ph % 12) === i;
      const hh = 8 + (on ? 26 * (0.4 + b) : 6 + 10 * Math.abs(Math.sin(i * 1.3 + t * 2)) * s.pulse);
      ctx.fillStyle = on ? c(s.palette.accent) : c(s.palette.ink, 0.4);
      ctx.fillRect(W - M - 12 * 15 + i * 15, H - 78 - hh, 8, hh);
    }
    ctx.font = `400 20px ${FONT_MONO}`; ctx.fillStyle = c(s.palette.ink, 0.45);
    ctx.fillText('ДНЕВНИК АТМОСФЕР', M, H - 46);
    ctx.textAlign = 'right';
    ctx.fillText(`${s.vector.bpm} BPM · ${(s.technique === 'ma' ? 'МА' : s.technique.toUpperCase())}`, W - M, H - 46);
    ctx.textAlign = 'left';
  }
}

// ——— вспомогательное
const ease = x => x * x * (3 - 2 * x);

function wrap(ctx, text, maxW, maxLines) {
  const words = text.split(/\s+/); const lines = []; let cur = '';
  for (const w of words) {
    const test = cur ? cur + ' ' + w : w;
    if (ctx.measureText(test).width > maxW && cur) { lines.push(cur); cur = w; } else cur = test;
  }
  if (cur) lines.push(cur);
  if (lines.length > maxLines) {
    const rest = lines.slice(maxLines - 1).join(' ');
    lines.length = maxLines - 1; lines.push(ellipsize(ctx, rest, maxW));
  }
  return lines;
}

function ellipsize(ctx, text, maxW) {
  if (ctx.measureText(text).width <= maxW) return text;
  while (text.length > 1 && ctx.measureText(text + '…').width > maxW) text = text.slice(0, -1);
  return text + '…';
}

function noiseCanvas(w, h, r, amp = 1) {
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d'); const img = ctx.createImageData(w, h);
  for (let i = 0; i < img.data.length; i += 4) {
    const v = 128 + (r() - 0.5) * 255 * amp;
    img.data[i] = img.data[i + 1] = img.data[i + 2] = v; img.data[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0); return cv;
}

function makeShapes(s, r) {
  const cols = ['accent', 'accent2', 'ink'];
  return {
    circles: Array.from({ length: 3 }, (_, i) => ({ x: M + r() * (W - 2 * M), y: 220 + r() * 1100, r: 90 + r() * 170, rings: 1 + Math.floor(r() * 4), col: cols[i % 2] })),
    lines: Array.from({ length: 7 }, () => {
      const a = (r() - 0.5) * Math.PI * 0.9, cx = r() * W, cy = 200 + r() * 1200, L = 400 + r() * 900;
      return { x1: cx - Math.cos(a) * L / 2, y1: cy - Math.sin(a) * L / 2, x2: cx + Math.cos(a) * L / 2, y2: cy + Math.sin(a) * L / 2, w: 2 + r() * 10 };
    }),
    tris: Array.from({ length: 2 }, (_, i) => {
      const x = M + r() * (W - 2 * M), y = 260 + r() * 1000, sz = 60 + r() * 110;
      return { col: cols[(i + 1) % 3], p: [x, y, x + sz, y + sz * 0.3, x + sz * 0.2, y + sz * 1.1] };
    }),
    checker: { x: M + r() * (W - 2 * M - 160), y: 300 + r() * 900, s: 28 + r() * 16 },
  };
}

function makeCollage(photos, win, r) {
  const n = photos.length;
  const cols = n > 2 ? 2 : 1, rows = Math.ceil(n / cols);
  const cellW = win.w / cols, cellH = win.h / rows;
  const cards = photos.map((img, i) => {
    const asp = img.width / img.height;
    // карточка с рамкой (+36 по ширине, +88 по высоте) должна поместиться в свою ячейку с запасом на поворот
    const w = Math.min(cellW * (n === 1 ? 0.82 : 0.9), (cellH * 0.86 - 88) * asp) * (0.92 + r() * 0.1);
    const col = i % cols, row = Math.floor(i / cols);
    return {
      x: win.x + cellW * (col + 0.5) + (r() - 0.5) * cellW * 0.12,
      y: win.y + cellH * (row + 0.5) + (r() - 0.5) * cellH * 0.08,
      w, rot: (r() - 0.5) * 0.22,
    };
  });
  cards.labels = Array.from({ length: 3 }, () => ({ x: win.x + 140 + r() * (win.w - 280), y: win.y + 60 + r() * (win.h - 120), rot: (r() - 0.5) * 0.2 }));
  return cards;
}

// Живописный слой «Моне»: мазки по направлению изофот, три прохода от крупных к мелким.
function paint(src, w, h, s, r) {
  const base = document.createElement('canvas'); base.width = w; base.height = h;
  const b = base.getContext('2d', { willReadFrequently: true });
  const k = Math.max(w / src.width, h / src.height);
  b.drawImage(src, (w - src.width * k) / 2, (h - src.height * k) / 2, src.width * k, src.height * k);
  const data = b.getImageData(0, 0, w, h).data;
  const out = document.createElement('canvas'); out.width = w; out.height = h;
  const o = out.getContext('2d');
  // мягкая подложка
  o.filter = 'blur(12px)';
  o.drawImage(base, 0, 0);
  o.filter = 'none';
  const lum = (x, y) => {
    x = Math.max(0, Math.min(w - 1, x | 0)); y = Math.max(0, Math.min(h - 1, y | 0));
    const i = (y * w + x) * 4; return data[i] * 0.3 + data[i + 1] * 0.59 + data[i + 2] * 0.11;
  };
  const paper = s.palette.paper;
  for (const [rad, dens] of [[22, 0.7], [12, 0.75], [6, 0.6]]) {
    const count = Math.round((w * h) / (rad * rad) * dens);
    for (let i = 0; i < count; i++) {
      const x = r() * w, y = r() * h;
      const gx = lum(x + 3, y) - lum(x - 3, y), gy = lum(x, y + 3) - lum(x, y - 3);
      const ang = Math.atan2(gy, gx) + Math.PI / 2 + (r() - 0.5) * 0.5;
      const pi = ((y | 0) * w + (x | 0)) * 4;
      const edge = Math.min(x, y, w - x, h - y);
      let col;
      if (edge < 46 && r() > edge / 46) col = hsl(paper[0], paper[1], paper[2], 0.9); // рваный край в цвет бумаги
      else {
        const j = 1 + (r() - 0.5) * 0.18;
        col = `rgba(${Math.min(255, data[pi] * j) | 0},${Math.min(255, data[pi + 1] * j) | 0},${Math.min(255, data[pi + 2] * j) | 0},0.78)`;
      }
      o.save(); o.translate(x, y); o.rotate(ang);
      o.fillStyle = col;
      o.beginPath(); o.ellipse(0, 0, rad * (1.4 + r()), rad * 0.45, 0, 0, Math.PI * 2); o.fill();
      o.restore();
    }
  }
  return out;
}
