// ВИЗУАЛЬНАЯ СИСТЕМА ДНЕВНИКА.
// Здесь все правила, по которым ощущение дня превращается в форму. Каждое правило пишет объяснение,
// поэтому всегда можно ответить, почему день выглядит именно так.

export const TECHNIQUES = {
  monet: {
    name: 'Импрессионизм · Моне',
    when: 'спокойные тёплые дни на воздухе',
    why: 'мазки растворяют контуры так же, как память растворяет детали; остаются свет и цвет',
  },
  kandinsky: {
    name: 'Геометрия · Кандинский',
    when: 'напряжённые и быстрые дни',
    why: 'линии, круги и жёсткая сетка работают как ритм: глаз не может остановиться',
  },
  film: {
    name: 'Плёнка · 35 мм',
    when: 'ностальгия, светлая грусть',
    why: 'зерно, молочные тени и дата-впечатка, как на мыльнице: кадр сразу кажется прошлым',
  },
  ma: {
    name: 'Ма · японский минимализм',
    when: 'тишина, одиночество, пауза',
    why: 'пустота становится содержанием: один акцент и много воздуха',
  },
  collage: {
    name: 'Коллаж · зин',
    when: 'шумные дни с людьми',
    why: 'много кадров, скотч и вырезки — неровный ритм, как разговор нескольких людей',
  },
};

const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const pct = v => `${Math.round(v * 100)}%`;
const hueName = h => {
  h = ((h % 360) + 360) % 360;
  if (h < 15 || h >= 340) return 'красный';
  if (h < 40) return 'охра';
  if (h < 65) return 'жёлтый';
  if (h < 160) return 'зелёный';
  if (h < 200) return 'бирюза';
  if (h < 255) return 'синий';
  if (h < 290) return 'фиолетовый';
  return 'пурпур';
};
// сдвиг оттенка к цели по кратчайшей дуге
const towards = (h, target, t) => {
  let d = ((target - h + 540) % 360) - 180;
  return (h + d * t + 360) % 360;
};

export function buildStyle({ analysis, photo, audio, date, songMeta }) {
  const m = analysis.mood;
  const explain = [];
  const song = analysis.song || {};

  // ——— 1. Музыка → параметры
  const bpm = audio?.bpm || song.tempo_bpm || Math.round(70 + m.energy * 70);
  const minor = (audio?.mode || song.mode) === 'minor';
  const musicEnergy = audio?.energy ?? song.energy ?? m.energy;
  const genre = (song.genre || '').toLowerCase();
  const electronic = /electro|техно|techno|house|synth|электрон|drum|edm|ambient techno/.test(genre + ' ' + (songMeta || '').toLowerCase());
  const tempoSrc = audio ? 'аудиоанализ' : song.tempo_bpm ? 'описание песни' : 'настроение текста';

  // ——— 2. Сведение трёх источников в один вектор дня
  const v = {
    valence: m.valence,
    energy: clamp(0.55 * m.energy + 0.45 * musicEnergy),
    warmth: clamp(0.6 * m.warmth + 0.25 * (photo?.warmth ?? 0.5) + 0.15 * (minor ? 0.35 : 0.65)),
    tension: clamp(m.tension + (minor && musicEnergy > 0.6 ? 0.15 : 0)),
    nostalgia: clamp(m.nostalgia + (minor ? 0.1 : 0) + (analysis.season === 'autumn' ? 0.08 : 0)),
    social: m.social,
    calm: clamp(m.calm + (bpm < 85 ? 0.12 : 0) - (bpm > 130 ? 0.15 : 0)),
  };
  const night = analysis.time_of_day === 'night';
  const evening = analysis.time_of_day === 'evening';

  // ——— 3. Выбор художественного приёма
  const scores = {
    monet: v.calm * 0.9 + v.warmth * 0.6 + (analysis.setting === 'nature' || analysis.setting === 'water' ? 0.35 : 0) - v.tension * 0.9 - v.energy * 0.3 + Math.max(0, v.valence) * 0.2,
    kandinsky: v.tension * 1.1 + v.energy * 0.7 + (['office', 'city'].includes(analysis.setting) ? 0.2 : 0) - v.calm * 0.5 + (electronic ? 0.3 : 0),
    film: v.nostalgia * 1.25 + (minor ? 0.12 : 0) + (bpm < 105 ? 0.05 : 0) - v.tension * 0.3,
    ma: v.calm * 0.7 + (1 - v.social) * 0.55 + (v.social < 0.15 ? 0.3 : 0) - v.energy * 0.45 + (v.valence < 0.2 ? 0.2 : 0) - v.warmth * 0.25,
    collage: v.social * 1.0 + v.energy * 0.6 + Math.max(0, v.valence) * 0.4 + ((photo?.count || 1) >= 3 ? 0.2 : 0) - v.calm * 0.35,
  };
  const ranked = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const technique = ranked[0][0];
  const secondary = ranked[1][1] > ranked[0][1] * 0.8 ? ranked[1][0] : null;
  const T = TECHNIQUES[technique];
  explain.push({
    rule: `Приём: ${T.name}${secondary ? ` + отголосок «${TECHNIQUES[secondary].name}»` : ''}`,
    because: `${techniqueReason(technique, v, analysis, electronic)} — ${T.why}`,
  });

  // ——— 4. Палитра: из фото, сдвинутая теплом дня, временем суток и сезоном
  const dom = photo?.palette?.[0]?.hsl || [30, 0.3, 0.5];
  const vivid = (photo?.palette || []).slice().sort((a, b) => b.hsl[1] * (1 - Math.abs(b.hsl[2] - 0.5)) - a.hsl[1] * (1 - Math.abs(a.hsl[2] - 0.5)))[0]?.hsl || dom;
  const warmTarget = 32, coolTarget = 215;
  const shift = Math.abs(v.warmth - 0.5) * 1.2;
  let baseHue = towards(dom[0], v.warmth >= 0.5 ? warmTarget : coolTarget, shift);
  let accentHue = towards(vivid[0], v.warmth >= 0.5 ? 22 : 200, shift * 0.6);
  const SEASON = { autumn: 30, winter: 205, spring: 345, summer: 48 };
  if (SEASON[analysis.season]) accentHue = towards(accentHue, SEASON[analysis.season], 0.3);
  if (night) baseHue = towards(baseHue, 228, 0.6);
  const val01 = (v.valence + 1) / 2;
  const sat = clamp(0.25 + val01 * 0.35 + v.energy * 0.2 - (minor ? 0.12 : 0) - v.calm * 0.1, 0.08, 0.85);
  const dark = night || (v.tension > 0.6 && v.calm < 0.35);
  const paper = dark
    ? [baseHue, clamp(sat * 0.35, 0.05, 0.3), night ? 0.08 : 0.11]
    : [baseHue, clamp(sat * 0.3, 0.05, 0.28), evening ? 0.86 : 0.93];
  const ink = dark ? [baseHue, 0.12, 0.9] : [baseHue, 0.25, 0.12];
  const accent = [accentHue, clamp(sat + 0.2, 0.25, 0.9), dark ? 0.6 : 0.5];
  const accent2 = [(accentHue + (v.tension > 0.5 ? 180 : 40)) % 360, clamp(sat, 0.2, 0.8), dark ? 0.5 : 0.42];
  explain.push({
    rule: `Палитра: ${hueName(baseHue)} фон, ${hueName(accentHue)} акцент, насыщенность ${pct(sat)}`,
    because: `на фото преобладает ${hueName(dom[0])}; тепло дня ${pct(v.warmth)} сдвигает её к ${v.warmth >= 0.5 ? 'тёплому' : 'холодному'}`
      + `${minor ? ', минорная песня приглушает цвет' : ''}${night ? ', ночь уводит фон в синий' : ''}${SEASON[analysis.season] ? `, сезон (${seasonRu(analysis.season)}) подкрашивает акцент` : ''}`,
  });

  // ——— 5. Обработка фото
  const grade = {
    saturation: clamp(0.55 + val01 * 0.45 + v.energy * 0.15 - (minor ? 0.15 : 0) - (technique === 'kandinsky' ? 0.35 : 0), 0.1, 1.4),
    contrast: clamp(0.88 + v.tension * 0.45 + v.energy * 0.1 - v.nostalgia * 0.1, 0.75, 1.5),
    lift: clamp(v.nostalgia * 0.14 + (technique === 'film' ? 0.06 : 0), 0, 0.2),
    tint: clamp(0.12 + v.nostalgia * 0.2 + (night ? 0.15 : 0), 0, 0.45),
    shadowHue: v.tension > 0.45 || night ? 220 : baseHue,
    highlightHue: v.warmth > 0.5 ? 38 : 200,
    tintSat: 0.5,
    exposure: night ? 0.82 : evening ? 0.95 : 1.03,
  };

  // ——— 6. Ритм: темп песни → длина кадра и тип перехода
  const beatsPerSlide = v.energy > 0.62 ? 4 : v.energy > 0.38 ? 8 : 16;
  const slideSec = clamp((beatsPerSlide * 60) / bpm, 1.4, 9);
  const transition = v.tension > 0.55 || v.energy > 0.72 ? 'cut' : v.calm > 0.55 ? 'long' : 'dissolve';
  const TR = { cut: 'резкая склейка', long: 'долгий наплыв', dissolve: 'мягкий наплыв' };
  explain.push({
    rule: `Ритм: кадр ${slideSec.toFixed(1)} с, ${TR[transition]}`,
    because: `${bpm} BPM (${tempoSrc}) × ${beatsPerSlide} долей — ${beatsPerSlide === 16 ? 'медленный день получает длинные кадры' : beatsPerSlide === 8 ? 'средний темп — кадр на такт и ещё один' : 'быстрый день — смена каждые 4 доли'}`
      + `${minor ? '; минор → больше воздуха и тишины' : ''}`,
  });

  // ——— 7. Фактура и воздух
  const grain = clamp(0.05 + v.nostalgia * 0.28 + (night ? 0.1 : 0) + (technique === 'film' ? 0.08 : 0), 0, 0.45);
  const air = clamp(v.calm * 0.45 + (1 - v.social) * 0.25 + (minor ? 0.12 : 0) + (technique === 'ma' ? 0.35 : 0), 0, 1);
  const pulse = clamp(v.energy * 0.6 + v.tension * 0.3);
  explain.push({
    rule: `Фактура: зерно ${pct(grain)}, воздух ${pct(air)}, пульсация ${pct(pulse)}`,
    because: `ностальгия ${pct(v.nostalgia)} даёт зерно; спокойствие ${pct(v.calm)} и мало людей (${pct(v.social)}) — больше пустоты вокруг фото; энергия музыки ${pct(musicEnergy)} — сила пульса на долях`,
  });

  // ——— 8. Типографика (шрифты постоянные, меняется только начертание)
  const type = {
    titleWeight: v.tension > 0.55 ? 700 : v.calm > 0.55 ? 400 : 500,
    italic: v.calm > 0.55 && v.tension < 0.35,
    tracking: v.tension > 0.55 ? -0.02 : 0.01,
    upper: technique === 'kandinsky',
  };

  // ——— 9. Голос озвучки — по правилам, а не случайно
  const voice = pickVoice(v, night, minor);
  explain.push({ rule: `Голос: ${voice.label}`, because: voice.because });

  return {
    vector: { ...v, bpm, minor, musicEnergy },
    technique, secondary, scores,
    palette: { paper, ink, accent, accent2, photo: (photo?.palette || []).map(p => p.hsl) },
    dark, grade, slideSec, transition, grain, air, pulse, type, voice,
    seed: hashStr(date + analysis.title),
    explain,
  };
}

function techniqueReason(t, v, a, electronic) {
  switch (t) {
    case 'monet': return `спокойно (${pct(v.calm)}) и тепло (${pct(v.warmth)})${a.setting === 'nature' || a.setting === 'water' ? ', на воздухе' : ''}, напряжения почти нет`;
    case 'kandinsky': return `напряжение ${pct(v.tension)} и энергия ${pct(v.energy)}${electronic ? ', электронная музыка' : ''}`;
    case 'film': return `ностальгия ${pct(v.nostalgia)} — главное ощущение дня`;
    case 'ma': return `тишина (${pct(v.calm)}) и мало людей (${pct(v.social)})`;
    case 'collage': return `много людей (${pct(v.social)}) и движения (${pct(v.energy)})`;
  }
  return '';
}

const seasonRu = s => ({ autumn: 'осень', winter: 'зима', spring: 'весна', summer: 'лето' }[s] || s);

function pickVoice(v, night, minor) {
  if (v.tension > 0.55) return {
    voice: 'ash', speed: 1.08, rate: 1.12, pitch: 0.95, label: 'собранный, чёткий, чуть быстрее',
    instructions: 'Говори собранно и чётко, чуть быстрее обычного, короткие паузы, без лишних эмоций — как человек, который держит себя в руках ночью перед сдачей.',
    because: `напряжение ${pct(v.tension)}: голос должен держать темп, а не утешать`,
  };
  if (v.energy > 0.62 && v.valence > 0.2) return {
    voice: 'nova', speed: 1.1, rate: 1.1, pitch: 1.1, label: 'живой, быстрый, с улыбкой',
    instructions: 'Рассказывай живо и с улыбкой в голосе, будто делишься с другом сразу после события, темп бодрый.',
    because: `энергия ${pct(v.energy)} и хорошее настроение — рассказ на одном дыхании`,
  };
  if (night && minor) return {
    voice: 'onyx', speed: 0.9, rate: 0.88, pitch: 0.85, label: 'низкий, медленный, ночной',
    instructions: 'Говори низко, медленно и тихо, с длинными паузами, ночная интонация, почти шёпотом.',
    because: 'ночь и минорная песня — низкий тихий голос',
  };
  if (v.nostalgia > 0.5) return {
    voice: 'ballad', speed: 0.92, rate: 0.9, pitch: 0.95, label: 'тихий, с паузами, вспоминающий',
    instructions: 'Читай тихо, с паузами, как будто перелистываешь старый альбом и вспоминаешь; лёгкая светлая грусть.',
    because: `ностальгия ${pct(v.nostalgia)} — интонация воспоминания`,
  };
  if (v.calm > 0.5 && v.warmth > 0.5) return {
    voice: 'sage', speed: 0.9, rate: 0.9, pitch: 1.0, label: 'тихий и тёплый',
    instructions: 'Говори тихо, тепло и медленно, мягко, как близкому человеку вечером под пледом.',
    because: `спокойно (${pct(v.calm)}) и тепло (${pct(v.warmth)}) — тёплый негромкий голос`,
  };
  return {
    voice: 'coral', speed: 1.0, rate: 1.0, pitch: 1.0, label: 'спокойный дружеский рассказ',
    instructions: 'Рассказывай спокойно и дружелюбно, естественным темпом, как в разговоре с другом.',
    because: 'ровный день без ярко выраженного полюса',
  };
}

export function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
